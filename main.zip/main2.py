from utils.Label_DataFrame import Label_DataFrame, distance

def get_result (key, enrolled_DB, threshold, album : dict) :
    key_image_set = set()
    key_image_embedding = enrolled_DB[key]
    for image in album.keys() :
        embeddings = album[image] # (n, 512)
        # for embedding in range(embeddings.shape[0]) :
        dis = distance(key_image_embedding, embeddings, 1)
        result = dis <= threshold
        if any(result) :
            key_image_set.add(image)

    return key_image_set

# key = 찾고 싶은 사람
# enrolled_DB : 찾고싶은 사람이 등록된 DB
# album은 전체 사진 DB
# threshold 는 같은 사람인지 아닌지 정하는 기준
